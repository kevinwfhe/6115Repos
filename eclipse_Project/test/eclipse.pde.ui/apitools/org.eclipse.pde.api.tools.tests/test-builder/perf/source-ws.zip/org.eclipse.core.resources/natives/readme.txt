This folder contains native code for supporting auto-refresh callbacks on Windows.
This source is in the base plugin because there are multiple Windows fragments that
share the same source.